#!/usr/bin/env node
/**
 * aggregate_filtered_subset.js
 * Reads data/filtered_subset_results.ndjson and produces data/filtered_subset_results.json with summary.
 */
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DATA_DIR = path.resolve(__dirname, '../data');
const NDJSON_FILE = path.join(DATA_DIR, 'filtered_subset_results.ndjson');
const OUT_FILE = path.join(DATA_DIR, 'filtered_subset_results.json');

function summarize(results) {
  const ok = results.filter(r => !r.error);
  const errors = results.filter(r => r.error);
  const sum = {
    totalDocs: results.length,
    ok: ok.length,
    errors: errors.length,
    totalGoals: ok.reduce((a, r) => a + r.goals, 0),
    totalBMPs: ok.reduce((a, r) => a + r.bmps, 0),
    totalRejected: ok.reduce((a, r) => a + r.rejected, 0),
    avgGoals: ok.length ? +(ok.reduce((a, r) => a + r.goals, 0) / ok.length).toFixed(2) : 0,
    avgBMPs: ok.length ? +(ok.reduce((a, r) => a + r.bmps, 0) / ok.length).toFixed(2) : 0,
    avgRejected: ok.length ? +(ok.reduce((a, r) => a + r.rejected, 0) / ok.length).toFixed(2) : 0,
    zeroGoal: ok.filter(r => r.zeroGoal).length,
    zeroBMP: ok.filter(r => r.zeroBMP).length,
    reasons: mergeReasonMaps(ok.map(r => r.rejectionReasons || {}))
  };
  return sum;
}
function mergeReasonMaps(maps) { const merged = {}; for (const m of maps) { for (const [k,v] of Object.entries(m)) merged[k]=(merged[k]||0)+v; } return merged; }

function main() {
  if (!fs.existsSync(NDJSON_FILE)) {
    console.error('[aggregate] No NDJSON file found, nothing to aggregate.');
    process.exit(1);
  }
  const lines = fs.readFileSync(NDJSON_FILE, 'utf8').split(/\r?\n/).filter(Boolean);
  const results = lines.map(l => { try { return JSON.parse(l); } catch { return { parseError: true, raw: l }; } });
  const summary = summarize(results.filter(r => !r.parseError));
  const payload = { generatedAt: new Date().toISOString(), count: results.length, results, summary };
  fs.writeFileSync(OUT_FILE, JSON.stringify(payload, null, 2));
  console.log('[aggregate] Wrote', OUT_FILE);
  console.log('[aggregate] Summary:', summary);
}

main();
